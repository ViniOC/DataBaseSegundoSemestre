DROP TABLE t_rhstu_bairro CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_cidade CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_consulta CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_consulta_forma_pagto CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_contato_paciente CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_email_paciente CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_endereco_paciente CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_estado CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_forma_pagamento CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_logradouro CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_medicamento CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_medico CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_paciente CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_paciente_plano_saude CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_plano_saude CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_prescicao_medica CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_telefone_paciente CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_tipo_contato CASCADE CONSTRAINTS;

DROP TABLE t_rhstu_unid_hospitalar CASCADE CONSTRAINTS;
