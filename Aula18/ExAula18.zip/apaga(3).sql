-- Gerado por Oracle SQL Developer Data Modeler 19.4.0.350.1424
--   em:        2022-06-22 11:49:18 BRT
--   site:      Oracle Database 11g
--   tipo:      Oracle Database 11g



DROP TABLE t_sip_bairro CASCADE CONSTRAINTS;

DROP TABLE t_sip_cidade CASCADE CONSTRAINTS;

DROP TABLE t_sip_dependente CASCADE CONSTRAINTS;

DROP TABLE t_sip_depto CASCADE CONSTRAINTS;

DROP TABLE t_sip_endereco CASCADE CONSTRAINTS;

DROP TABLE t_sip_estado CASCADE CONSTRAINTS;

DROP TABLE t_sip_funcionario CASCADE CONSTRAINTS;

DROP TABLE t_sip_funcionario_endereco CASCADE CONSTRAINTS;

DROP TABLE t_sip_implantacao CASCADE CONSTRAINTS;

DROP TABLE t_sip_projeto CASCADE CONSTRAINTS;

DROP TABLE t_sip_tipo_endereco CASCADE CONSTRAINTS;

DROP TABLE t_sip_TELEFONE CASCADE CONSTRAINTS;
